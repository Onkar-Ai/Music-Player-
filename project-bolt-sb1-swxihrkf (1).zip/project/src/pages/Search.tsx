import React, { useState } from 'react';
import { Search as SearchIcon, Play, Clock } from 'lucide-react';
import { Song, Artist } from '../types/music';
import { mockSongs, mockArtists } from '../data/mockData';

interface SearchProps {
  onSongSelect: (song: Song) => void;
}

const Search: React.FC<SearchProps> = ({ onSongSelect }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('all');

  const filteredSongs = mockSongs.filter(
    song =>
      song.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      song.artist.toLowerCase().includes(searchQuery.toLowerCase()) ||
      song.album.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredArtists = mockArtists.filter(
    artist => artist.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const genres = [
    { name: 'Pop', color: 'bg-pink-500', image: 'https://images.pexels.com/photos/1540406/pexels-photo-1540406.jpeg?auto=compress&cs=tinysrgb&w=300' },
    { name: 'Hip-Hop', color: 'bg-red-500', image: 'https://images.pexels.com/photos/1699161/pexels-photo-1699161.jpeg?auto=compress&cs=tinysrgb&w=300' },
    { name: 'Rock', color: 'bg-purple-500', image: 'https://images.pexels.com/photos/1389429/pexels-photo-1389429.jpeg?auto=compress&cs=tinysrgb&w=300' },
    { name: 'Electronic', color: 'bg-blue-500', image: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=300' },
    { name: 'Jazz', color: 'bg-yellow-500', image: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=300' },
    { name: 'Classical', color: 'bg-green-500', image: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=300' },
  ];

  const tabs = [
    { id: 'all', label: 'All' },
    { id: 'songs', label: 'Songs' },
    { id: 'artists', label: 'Artists' },
    { id: 'albums', label: 'Albums' },
    { id: 'playlists', label: 'Playlists' },
  ];

  return (
    <div className="p-6 pb-32">
      {/* Search Bar */}
      <div className="mb-8">
        <div className="relative max-w-md">
          <SearchIcon size={20} className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="What do you want to listen to?"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-white/10 border border-gray-700/50 rounded-full text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50 backdrop-blur-sm transition-all duration-200"
          />
        </div>
      </div>

      {!searchQuery ? (
        // Browse Categories
        <div>
          <h2 className="text-2xl font-bold text-white mb-6">Browse all</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {genres.map((genre) => (
              <div
                key={genre.name}
                className={`${genre.color} rounded-lg p-6 relative overflow-hidden cursor-pointer hover:scale-105 transition-transform duration-200 group`}
              >
                <h3 className="text-white font-bold text-xl mb-4">{genre.name}</h3>
                <img
                  src={genre.image}
                  alt={genre.name}
                  className="absolute -bottom-2 -right-2 w-20 h-20 object-cover rounded-lg transform rotate-25 group-hover:rotate-12 transition-transform duration-300"
                />
              </div>
            ))}
          </div>
        </div>
      ) : (
        // Search Results
        <div>
          {/* Tabs */}
          <div className="flex gap-4 mb-6 overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 rounded-full whitespace-nowrap transition-all duration-200 ${
                  activeTab === tab.id
                    ? 'bg-white text-black font-medium'
                    : 'bg-white/10 text-gray-300 hover:bg-white/20 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Results */}
          {(activeTab === 'all' || activeTab === 'songs') && filteredSongs.length > 0 && (
            <section className="mb-8">
              <h3 className="text-xl font-bold text-white mb-4">Songs</h3>
              <div className="space-y-2">
                {filteredSongs.slice(0, activeTab === 'songs' ? undefined : 4).map((song, index) => (
                  <div
                    key={song.id}
                    onClick={() => onSongSelect(song)}
                    className="flex items-center gap-4 p-3 rounded-lg hover:bg-white/5 transition-all duration-200 group cursor-pointer"
                  >
                    <div className="w-8 text-center">
                      <span className="text-gray-400 group-hover:hidden">{index + 1}</span>
                      <Play size={16} className="text-white hidden group-hover:block mx-auto" />
                    </div>
                    <img
                      src={song.coverUrl}
                      alt={song.album}
                      className="w-12 h-12 rounded object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-white font-medium truncate group-hover:text-purple-400 transition-colors">
                        {song.title}
                      </h4>
                      <p className="text-gray-400 text-sm truncate">{song.artist}</p>
                    </div>
                    <div className="hidden md:block flex-1 min-w-0">
                      <p className="text-gray-400 text-sm truncate">{song.album}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <Clock size={16} className="text-gray-400" />
                      <span className="text-gray-400 text-sm w-12 text-right">{song.duration}</span>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {(activeTab === 'all' || activeTab === 'artists') && filteredArtists.length > 0 && (
            <section className="mb-8">
              <h3 className="text-xl font-bold text-white mb-4">Artists</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
                {filteredArtists.slice(0, activeTab === 'artists' ? undefined : 6).map((artist) => (
                  <div
                    key={artist.id}
                    className="bg-white/5 hover:bg-white/10 rounded-lg p-4 transition-all duration-300 cursor-pointer group"
                  >
                    <div className="relative mb-4">
                      <img
                        src={artist.imageUrl}
                        alt={artist.name}
                        className="w-full aspect-square object-cover rounded-full shadow-lg group-hover:shadow-xl transition-shadow duration-300"
                      />
                      <button className="absolute bottom-2 right-2 w-12 h-12 bg-green-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300 hover:scale-105">
                        <Play size={16} className="text-black ml-1" />
                      </button>
                    </div>
                    <h3 className="font-semibold text-white mb-2 truncate">{artist.name}</h3>
                    <p className="text-gray-400 text-sm">Artist • {artist.followers} followers</p>
                  </div>
                ))}
              </div>
            </section>
          )}

          {filteredSongs.length === 0 && filteredArtists.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-400 text-lg">No results found for "{searchQuery}"</p>
              <p className="text-gray-500 text-sm mt-2">Try searching for something else</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Search;