import React, { useState } from 'react';
import { MoreHorizontal, Play, Clock, Heart, Download } from 'lucide-react';
import { Song, Playlist } from '../types/music';
import { mockSongs, mockPlaylists } from '../data/mockData';

interface LibraryProps {
  onSongSelect: (song: Song) => void;
  onPlaylistSelect: (playlist: Playlist) => void;
}

const Library: React.FC<LibraryProps> = ({ onSongSelect, onPlaylistSelect }) => {
  const [activeTab, setActiveTab] = useState('all');
  const [sortBy, setSortBy] = useState('recent');

  const tabs = [
    { id: 'all', label: 'All' },
    { id: 'playlists', label: 'Playlists' },
    { id: 'artists', label: 'Artists' },
    { id: 'albums', label: 'Albums' },
  ];

  const sortOptions = [
    { id: 'recent', label: 'Recently added' },
    { id: 'alphabetical', label: 'Alphabetical' },
    { id: 'creator', label: 'Creator' },
  ];

  const likedSongs = mockSongs.slice(0, 4);
  const userPlaylists = mockPlaylists;

  return (
    <div className="p-6 pb-32">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-white">Your Library</h1>
        <div className="flex items-center gap-4">
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="bg-white/10 border border-gray-700/50 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/50"
          >
            {sortOptions.map((option) => (
              <option key={option.id} value={option.id} className="bg-gray-900">
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-full whitespace-nowrap transition-all duration-200 ${
              activeTab === tab.id
                ? 'bg-white text-black font-medium'
                : 'bg-white/10 text-gray-300 hover:bg-white/20 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="space-y-6">
        {/* Liked Songs */}
        {(activeTab === 'all' || activeTab === 'playlists') && (
          <div className="bg-gradient-to-br from-purple-800 to-blue-800 rounded-lg p-6 hover:from-purple-700 hover:to-blue-700 transition-all duration-300 cursor-pointer group">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                <Heart size={24} className="text-white fill-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-white font-bold text-lg">Liked Songs</h3>
                <p className="text-gray-200">{likedSongs.length} liked songs</p>
              </div>
              <button className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300 hover:scale-105">
                <Play size={16} className="text-black ml-1" />
              </button>
            </div>
          </div>
        )}

        {/* Downloaded Music */}
        {(activeTab === 'all' || activeTab === 'playlists') && (
          <div className="bg-gradient-to-br from-green-800 to-emerald-800 rounded-lg p-6 hover:from-green-700 hover:to-emerald-700 transition-all duration-300 cursor-pointer group">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-500 rounded-lg flex items-center justify-center">
                <Download size={24} className="text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-white font-bold text-lg">Downloaded</h3>
                <p className="text-gray-200">12 downloaded songs</p>
              </div>
              <button className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300 hover:scale-105">
                <Play size={16} className="text-black ml-1" />
              </button>
            </div>
          </div>
        )}

        {/* User Playlists */}
        {(activeTab === 'all' || activeTab === 'playlists') && (
          <div className="space-y-3">
            {userPlaylists.map((playlist) => (
              <div
                key={playlist.id}
                onClick={() => onPlaylistSelect(playlist)}
                className="flex items-center gap-4 p-3 rounded-lg hover:bg-white/5 transition-all duration-200 group cursor-pointer"
              >
                <img
                  src={playlist.coverUrl}
                  alt={playlist.name}
                  className="w-16 h-16 rounded-lg object-cover shadow-lg"
                />
                <div className="flex-1 min-w-0">
                  <h3 className="text-white font-semibold truncate group-hover:text-purple-400 transition-colors">
                    {playlist.name}
                  </h3>
                  <p className="text-gray-400 text-sm truncate">
                    Playlist • {playlist.songs.length} songs
                  </p>
                </div>
                <button className="opacity-0 group-hover:opacity-100 p-2 text-gray-400 hover:text-white transition-all duration-200">
                  <MoreHorizontal size={20} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Recently Played */}
        {activeTab === 'all' && (
          <div>
            <h2 className="text-xl font-bold text-white mb-4">Recently played</h2>
            <div className="space-y-2">
              {mockSongs.slice(0, 5).map((song, index) => (
                <div
                  key={song.id}
                  onClick={() => onSongSelect(song)}
                  className="flex items-center gap-4 p-3 rounded-lg hover:bg-white/5 transition-all duration-200 group cursor-pointer"
                >
                  <div className="w-8 text-center">
                    <span className="text-gray-400 group-hover:hidden">{index + 1}</span>
                    <Play size={16} className="text-white hidden group-hover:block mx-auto" />
                  </div>
                  <img
                    src={song.coverUrl}
                    alt={song.album}
                    className="w-12 h-12 rounded object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-white font-medium truncate group-hover:text-purple-400 transition-colors">
                      {song.title}
                    </h4>
                    <p className="text-gray-400 text-sm truncate">{song.artist}</p>
                  </div>
                  <div className="hidden md:block flex-1 min-w-0">
                    <p className="text-gray-400 text-sm truncate">{song.album}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <Clock size={16} className="text-gray-400" />
                    <span className="text-gray-400 text-sm w-12 text-right">{song.duration}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Library;