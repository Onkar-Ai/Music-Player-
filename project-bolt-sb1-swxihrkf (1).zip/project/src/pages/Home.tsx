import React from 'react';
import { Play, Clock } from 'lucide-react';
import { Song, Playlist } from '../types/music';
import { mockSongs, mockPlaylists } from '../data/mockData';

interface HomeProps {
  onSongSelect: (song: Song) => void;
  onPlaylistSelect: (playlist: Playlist) => void;
}

const Home: React.FC<HomeProps> = ({ onSongSelect, onPlaylistSelect }) => {
  const featuredPlaylists = mockPlaylists.slice(0, 6);
  const recentlyPlayed = mockSongs.slice(0, 6);

  return (
    <div className="p-6 pb-32 space-y-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-white mb-2">
          Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'}
        </h1>
        <p className="text-gray-400">Welcome back to your music</p>
      </div>

      {/* Quick Access */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {recentlyPlayed.map((song, index) => (
          <button
            key={song.id}
            onClick={() => onSongSelect(song)}
            className="flex items-center gap-4 bg-white/5 hover:bg-white/10 rounded-lg p-3 transition-all duration-200 group"
          >
            <img
              src={song.coverUrl}
              alt={song.album}
              className="w-16 h-16 rounded-lg object-cover shadow-lg"
            />
            <div className="flex-1 text-left">
              <h3 className="text-white font-semibold truncate">{song.title}</h3>
              <p className="text-gray-400 text-sm truncate">{song.artist}</p>
            </div>
            <Play 
              size={20} 
              className="text-green-500 opacity-0 group-hover:opacity-100 transform group-hover:scale-110 transition-all duration-200" 
            />
          </button>
        ))}
      </div>

      {/* Made For You */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Made for you</h2>
          <button className="text-gray-400 hover:text-white text-sm font-medium transition-colors">
            Show all
          </button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6 gap-6">
          {featuredPlaylists.map((playlist) => (
            <div
              key={playlist.id}
              onClick={() => onPlaylistSelect(playlist)}
              className="bg-white/5 hover:bg-white/10 rounded-lg p-4 transition-all duration-300 cursor-pointer group"
            >
              <div className="relative mb-4">
                <img
                  src={playlist.coverUrl}
                  alt={playlist.name}
                  className="w-full aspect-square object-cover rounded-lg shadow-lg group-hover:shadow-xl transition-shadow duration-300"
                />
                <button className="absolute bottom-2 right-2 w-12 h-12 bg-green-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300 hover:scale-105">
                  <Play size={16} className="text-black ml-1" />
                </button>
              </div>
              <h3 className="font-semibold text-white mb-2 truncate">{playlist.name}</h3>
              <p className="text-gray-400 text-sm line-clamp-2">{playlist.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Recently Played */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Recently played</h2>
          <button className="text-gray-400 hover:text-white text-sm font-medium transition-colors">
            Show all
          </button>
        </div>
        <div className="space-y-2">
          {mockSongs.map((song, index) => (
            <div
              key={song.id}
              onClick={() => onSongSelect(song)}
              className="flex items-center gap-4 p-3 rounded-lg hover:bg-white/5 transition-all duration-200 group cursor-pointer"
            >
              <div className="w-8 text-center">
                <span className="text-gray-400 group-hover:hidden">{index + 1}</span>
                <Play size={16} className="text-white hidden group-hover:block mx-auto" />
              </div>
              <img
                src={song.coverUrl}
                alt={song.album}
                className="w-12 h-12 rounded object-cover"
              />
              <div className="flex-1 min-w-0">
                <h4 className="text-white font-medium truncate group-hover:text-purple-400 transition-colors">
                  {song.title}
                </h4>
                <p className="text-gray-400 text-sm truncate">{song.artist}</p>
              </div>
              <div className="hidden md:block flex-1 min-w-0">
                <p className="text-gray-400 text-sm truncate">{song.album}</p>
              </div>
              <div className="flex items-center gap-4">
                <Clock size={16} className="text-gray-400" />
                <span className="text-gray-400 text-sm w-12 text-right">{song.duration}</span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;