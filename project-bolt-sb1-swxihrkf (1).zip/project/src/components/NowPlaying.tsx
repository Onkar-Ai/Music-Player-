import React from 'react';
import { Heart, MoreHorizontal, Play, Pause, SkipBack, SkipForward, Shuffle, Repeat, Volume2 } from 'lucide-react';
import { Song } from '../types/music';

interface NowPlayingProps {
  currentSong: Song | null;
  isPlaying: boolean;
  onPlayPause: () => void;
  onNext: () => void;
  onPrevious: () => void;
  onToggleLike: () => void;
  isLiked: boolean;
}

const NowPlaying: React.FC<NowPlayingProps> = ({
  currentSong,
  isPlaying,
  onPlayPause,
  onNext,
  onPrevious,
  onToggleLike,
  isLiked,
}) => {
  if (!currentSong) {
    return (
      <div className="p-6 pb-32 flex items-center justify-center h-full">
        <div className="text-center">
          <div className="w-32 h-32 bg-gradient-to-br from-purple-600/20 to-cyan-600/20 rounded-full flex items-center justify-center mb-6 mx-auto">
            <Play size={48} className="text-gray-400 ml-2" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">No song playing</h2>
          <p className="text-gray-400">Select a song to see it here</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 pb-32 max-w-4xl mx-auto">
      {/* Album Art & Song Info */}
      <div className="flex flex-col lg:flex-row gap-8 mb-8">
        <div className="lg:w-1/2">
          <div className="relative group">
            <img
              src={currentSong.coverUrl}
              alt={currentSong.album}
              className="w-full aspect-square object-cover rounded-2xl shadow-2xl group-hover:shadow-purple-500/25 transition-all duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </div>
        </div>
        
        <div className="lg:w-1/2 flex flex-col justify-end">
          <div className="mb-8">
            <p className="text-sm font-medium text-gray-400 uppercase tracking-wider mb-2">
              Now Playing
            </p>
            <h1 className="text-4xl lg:text-5xl font-bold text-white mb-4 leading-tight">
              {currentSong.title}
            </h1>
            <p className="text-xl text-gray-300 mb-6">{currentSong.artist}</p>
            <p className="text-gray-400">{currentSong.album}</p>
          </div>
          
          <div className="flex items-center gap-4 mb-8">
            <button
              onClick={onToggleLike}
              className={`p-3 rounded-full transition-all duration-200 ${
                isLiked
                  ? 'text-red-500 hover:text-red-400 hover:scale-110'
                  : 'text-gray-400 hover:text-white hover:scale-110'
              }`}
            >
              <Heart size={24} fill={isLiked ? 'currentColor' : 'none'} />
            </button>
            <button className="p-3 text-gray-400 hover:text-white transition-all duration-200 hover:scale-110">
              <MoreHorizontal size={24} />
            </button>
          </div>
        </div>
      </div>

      {/* Enhanced Player Controls */}
      <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-2">
            <span className="text-sm text-gray-400 w-12">0:00</span>
            <div className="flex-1 h-2 bg-gray-700/50 rounded-full cursor-pointer group">
              <div className="h-full w-1/3 bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full group-hover:from-purple-400 group-hover:to-cyan-400 transition-all duration-200 relative">
                <div className="absolute right-0 top-1/2 transform translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>
            <span className="text-sm text-gray-400 w-12 text-right">{currentSong.duration}</span>
          </div>
        </div>

        {/* Control Buttons */}
        <div className="flex items-center justify-center gap-6 mb-8">
          <button className="p-3 text-gray-400 hover:text-green-500 transition-all duration-200 hover:scale-110">
            <Shuffle size={20} />
          </button>
          
          <button
            onClick={onPrevious}
            className="p-3 text-gray-400 hover:text-white transition-all duration-200 hover:scale-110"
          >
            <SkipBack size={24} />
          </button>
          
          <button
            onClick={onPlayPause}
            className="p-4 bg-white text-black rounded-full hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            {isPlaying ? <Pause size={28} /> : <Play size={28} className="ml-1" />}
          </button>
          
          <button
            onClick={onNext}
            className="p-3 text-gray-400 hover:text-white transition-all duration-200 hover:scale-110"
          >
            <SkipForward size={24} />
          </button>
          
          <button className="p-3 text-gray-400 hover:text-green-500 transition-all duration-200 hover:scale-110">
            <Repeat size={20} />
          </button>
        </div>

        {/* Volume Control */}
        <div className="flex items-center justify-center gap-4">
          <Volume2 size={20} className="text-gray-400" />
          <div className="w-32 h-1 bg-gray-700/50 rounded-full cursor-pointer group">
            <div className="h-full w-3/4 bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full group-hover:from-purple-400 group-hover:to-cyan-400 transition-all duration-200 relative">
              <div className="absolute right-0 top-1/2 transform translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          </div>
        </div>
      </div>

      {/* Lyrics Section */}
      <div className="mt-8 bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
        <h3 className="text-xl font-bold text-white mb-6">Lyrics</h3>
        <div className="space-y-4 text-gray-300 leading-relaxed">
          <p className="hover:text-white transition-colors duration-200 cursor-pointer">
            Yeah, I feel like I'm just missing something whenever you're gone
          </p>
          <p className="hover:text-white transition-colors duration-200 cursor-pointer">
            Yeah, I am never wrong about you, I can't move on
          </p>
          <p className="hover:text-white transition-colors duration-200 cursor-pointer text-white">
            I feel like I'm just missing something whenever you're gone <span className="text-purple-400">♪</span>
          </p>
          <p className="hover:text-white transition-colors duration-200 cursor-pointer">
            Yeah, I am never wrong about you, I can't move on
          </p>
        </div>
      </div>
    </div>
  );
};

export default NowPlaying;