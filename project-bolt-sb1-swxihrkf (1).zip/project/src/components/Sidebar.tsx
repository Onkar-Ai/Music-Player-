import React from 'react';
import { Home, Search, Library, Heart, Plus } from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  onPageChange: (page: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentPage, onPageChange }) => {
  const menuItems = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'search', icon: Search, label: 'Search' },
    { id: 'library', icon: Library, label: 'Your Library' },
  ];

  return (
    <div className="w-64 bg-black/95 backdrop-blur-sm border-r border-gray-800/50 h-full flex flex-col">
      {/* Logo */}
      <div className="p-6">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
          SoundWave
        </h1>
      </div>

      {/* Main Menu */}
      <nav className="px-3 mb-8">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onPageChange(item.id)}
              className={`w-full flex items-center gap-4 px-3 py-3 rounded-lg text-left transition-all duration-200 group ${
                isActive
                  ? 'bg-gradient-to-r from-purple-600/20 to-cyan-600/20 text-white border border-purple-500/30'
                  : 'text-gray-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Icon 
                size={20} 
                className={`transition-all duration-200 ${
                  isActive 
                    ? 'text-purple-400' 
                    : 'group-hover:text-cyan-400'
                }`} 
              />
              <span className="font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Create Playlist */}
      <div className="px-3 mb-6">
        <button className="w-full flex items-center gap-4 px-3 py-3 rounded-lg text-gray-300 hover:text-white hover:bg-white/5 transition-all duration-200 group">
          <Plus size={20} className="group-hover:text-green-400 transition-colors duration-200" />
          <span className="font-medium">Create Playlist</span>
        </button>
        <button className="w-full flex items-center gap-4 px-3 py-3 rounded-lg text-gray-300 hover:text-white hover:bg-white/5 transition-all duration-200 group">
          <Heart size={20} className="group-hover:text-red-400 transition-colors duration-200" />
          <span className="font-medium">Liked Songs</span>
        </button>
      </div>

      {/* Recently Played */}
      <div className="px-3 flex-1 overflow-y-auto">
        <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">
          Recently Played
        </h3>
        <div className="space-y-2">
          {['My Playlist #1', 'Chill Mix', 'Workout Hits', 'Road Trip Songs'].map((playlist, index) => (
            <button
              key={index}
              className="w-full text-left px-3 py-2 rounded-md text-gray-300 hover:text-white hover:bg-white/5 transition-all duration-200 truncate"
            >
              {playlist}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;