import React, { useState, useEffect } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, Shuffle, Repeat, Heart } from 'lucide-react';
import { Song } from '../types/music';

interface PlayerControlsProps {
  currentSong: Song | null;
  isPlaying: boolean;
  onPlayPause: () => void;
  onNext: () => void;
  onPrevious: () => void;
  onToggleLike: () => void;
  isLiked: boolean;
}

const PlayerControls: React.FC<PlayerControlsProps> = ({
  currentSong,
  isPlaying,
  onPlayPause,
  onNext,
  onPrevious,
  onToggleLike,
  isLiked,
}) => {
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(70);
  const [currentTime, setCurrentTime] = useState('0:00');
  const [isShuffled, setIsShuffled] = useState(false);
  const [repeatMode, setRepeatMode] = useState(0); // 0: off, 1: all, 2: one

  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setProgress((prev) => {
          const newProgress = prev + 0.5;
          return newProgress >= 100 ? 0 : newProgress;
        });
        
        // Update current time (mock)
        const minutes = Math.floor((progress / 100) * 200 / 60);
        const seconds = Math.floor((progress / 100) * 200 % 60);
        setCurrentTime(`${minutes}:${seconds.toString().padStart(2, '0')}`);
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [isPlaying, progress]);

  if (!currentSong) {
    return (
      <div className="fixed bottom-0 left-0 right-0 bg-black/95 backdrop-blur-sm border-t border-gray-800/50 p-4">
        <div className="flex items-center justify-center text-gray-500">
          Select a song to start playing
        </div>
      </div>
    );
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-black/95 via-gray-900/95 to-black/95 backdrop-blur-md border-t border-gray-800/50">
      {/* Progress Bar */}
      <div className="relative">
        <div className="h-1 bg-gray-700/50">
          <div 
            className="h-full bg-gradient-to-r from-purple-500 to-cyan-500 transition-all duration-1000 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div 
          className="absolute top-0 w-3 h-3 bg-white rounded-full transform -translate-y-1 -translate-x-1.5 shadow-lg opacity-0 hover:opacity-100 transition-opacity cursor-pointer"
          style={{ left: `${progress}%` }}
        />
      </div>

      <div className="flex items-center justify-between p-4">
        {/* Currently Playing */}
        <div className="flex items-center gap-4 min-w-0 flex-1">
          <div className="relative group">
            <img
              src={currentSong.coverUrl}
              alt={currentSong.album}
              className="w-14 h-14 rounded-lg object-cover shadow-lg group-hover:scale-105 transition-transform duration-200"
            />
            <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg" />
          </div>
          <div className="min-w-0 flex-1">
            <h4 className="text-white font-semibold truncate hover:text-purple-400 transition-colors cursor-pointer">
              {currentSong.title}
            </h4>
            <p className="text-gray-400 text-sm truncate hover:text-white transition-colors cursor-pointer">
              {currentSong.artist}
            </p>
          </div>
          <button
            onClick={onToggleLike}
            className={`p-2 rounded-full transition-all duration-200 ${
              isLiked
                ? 'text-red-500 hover:text-red-400 hover:scale-110'
                : 'text-gray-400 hover:text-white hover:scale-110'
            }`}
          >
            <Heart size={20} fill={isLiked ? 'currentColor' : 'none'} />
          </button>
        </div>

        {/* Player Controls */}
        <div className="flex flex-col items-center gap-2 px-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsShuffled(!isShuffled)}
              className={`p-2 rounded-full transition-all duration-200 ${
                isShuffled
                  ? 'text-green-500 hover:text-green-400'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Shuffle size={18} />
            </button>
            
            <button
              onClick={onPrevious}
              className="p-2 text-gray-400 hover:text-white transition-all duration-200 hover:scale-110"
            >
              <SkipBack size={20} />
            </button>
            
            <button
              onClick={onPlayPause}
              className="p-3 bg-white text-black rounded-full hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              {isPlaying ? <Pause size={20} /> : <Play size={20} className="ml-1" />}
            </button>
            
            <button
              onClick={onNext}
              className="p-2 text-gray-400 hover:text-white transition-all duration-200 hover:scale-110"
            >
              <SkipForward size={20} />
            </button>
            
            <button
              onClick={() => setRepeatMode((prev) => (prev + 1) % 3)}
              className={`p-2 rounded-full transition-all duration-200 ${
                repeatMode > 0
                  ? 'text-green-500 hover:text-green-400'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Repeat size={18} />
              {repeatMode === 2 && (
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-green-500 rounded-full" />
              )}
            </button>
          </div>
          
          <div className="flex items-center gap-2 text-xs text-gray-400 w-full">
            <span className="w-10 text-right">{currentTime}</span>
            <div className="w-80 h-1 bg-gray-700 rounded-full cursor-pointer group">
              <div 
                className="h-full bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full group-hover:from-purple-400 group-hover:to-cyan-400 transition-all duration-200"
                style={{ width: `${progress}%` }}
              />
            </div>
            <span className="w-10">{currentSong.duration}</span>
          </div>
        </div>

        {/* Volume Control */}
        <div className="flex items-center gap-3 min-w-0 flex-1 justify-end">
          <Volume2 size={20} className="text-gray-400" />
          <div className="w-24 h-1 bg-gray-700 rounded-full cursor-pointer group">
            <div 
              className="h-full bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full group-hover:from-purple-400 group-hover:to-cyan-400 transition-all duration-200"
              style={{ width: `${volume}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlayerControls;