import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import PlayerControls from './components/PlayerControls';
import NowPlaying from './components/NowPlaying';
import Login from './pages/Login';
import Home from './pages/Home';
import Search from './pages/Search';
import Library from './pages/Library';
import { Song, Playlist } from './types/music';
import { mockSongs } from './data/mockData';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentPage, setCurrentPage] = useState('home');
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentPlaylist, setCurrentPlaylist] = useState<Song[]>(mockSongs);
  const [currentSongIndex, setCurrentSongIndex] = useState(0);
  const [likedSongs, setLikedSongs] = useState<Set<string>>(new Set());

  const handleLogin = () => {
    setIsLoggedIn(true);
  };

  const handleSongSelect = (song: Song) => {
    setCurrentSong(song);
    setIsPlaying(true);
    const songIndex = currentPlaylist.findIndex(s => s.id === song.id);
    if (songIndex !== -1) {
      setCurrentSongIndex(songIndex);
    }
  };

  const handlePlaylistSelect = (playlist: Playlist) => {
    setCurrentPlaylist(playlist.songs);
    if (playlist.songs.length > 0) {
      setCurrentSong(playlist.songs[0]);
      setCurrentSongIndex(0);
      setIsPlaying(true);
    }
  };

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleNext = () => {
    const nextIndex = (currentSongIndex + 1) % currentPlaylist.length;
    setCurrentSongIndex(nextIndex);
    setCurrentSong(currentPlaylist[nextIndex]);
    setIsPlaying(true);
  };

  const handlePrevious = () => {
    const prevIndex = currentSongIndex === 0 ? currentPlaylist.length - 1 : currentSongIndex - 1;
    setCurrentSongIndex(prevIndex);
    setCurrentSong(currentPlaylist[prevIndex]);
    setIsPlaying(true);
  };

  const handleToggleLike = () => {
    if (currentSong) {
      const newLikedSongs = new Set(likedSongs);
      if (likedSongs.has(currentSong.id)) {
        newLikedSongs.delete(currentSong.id);
      } else {
        newLikedSongs.add(currentSong.id);
      }
      setLikedSongs(newLikedSongs);
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home onSongSelect={handleSongSelect} onPlaylistSelect={handlePlaylistSelect} />;
      case 'search':
        return <Search onSongSelect={handleSongSelect} />;
      case 'library':
        return <Library onSongSelect={handleSongSelect} onPlaylistSelect={handlePlaylistSelect} />;
      case 'nowplaying':
        return (
          <NowPlaying
            currentSong={currentSong}
            isPlaying={isPlaying}
            onPlayPause={handlePlayPause}
            onNext={handleNext}
            onPrevious={handlePrevious}
            onToggleLike={handleToggleLike}
            isLiked={currentSong ? likedSongs.has(currentSong.id) : false}
          />
        );
      default:
        return <Home onSongSelect={handleSongSelect} onPlaylistSelect={handlePlaylistSelect} />;
    }
  };

  // Show login page if not logged in
  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800 text-white flex overflow-hidden">
      {/* Sidebar */}
      <div className="hidden md:block">
        <Sidebar currentPage={currentPage} onPageChange={setCurrentPage} />
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto">
        {/* Mobile Header */}
        <div className="md:hidden bg-black/95 backdrop-blur-sm border-b border-gray-800/50 p-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
              SoundWave
            </h1>
            <div className="flex gap-2">
              {['home', 'search', 'library'].map((page) => (
                <button
                  key={page}
                  onClick={() => setCurrentPage(page)}
                  className={`px-3 py-1 rounded-full text-sm transition-all duration-200 ${
                    currentPage === page
                      ? 'bg-white text-black'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {page.charAt(0).toUpperCase() + page.slice(1)}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Page Content */}
        {renderPage()}
      </div>

      {/* Now Playing Button (Mobile) */}
      {currentSong && (
        <button
          onClick={() => setCurrentPage('nowplaying')}
          className="md:hidden fixed top-4 right-4 w-12 h-12 bg-gradient-to-br from-purple-600 to-cyan-600 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-200 z-20"
        >
          <img
            src={currentSong.coverUrl}
            alt={currentSong.title}
            className="w-8 h-8 rounded-full object-cover"
          />
        </button>
      )}

      {/* Player Controls */}
      <PlayerControls
        currentSong={currentSong}
        isPlaying={isPlaying}
        onPlayPause={handlePlayPause}
        onNext={handleNext}
        onPrevious={handlePrevious}
        onToggleLike={handleToggleLike}
        isLiked={currentSong ? likedSongs.has(currentSong.id) : false}
      />
    </div>
  );
}

export default App;